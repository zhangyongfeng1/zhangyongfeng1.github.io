package com.bignerdranch.android.activity_text;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    public static final String TAG = "MainActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Log.w(TAG,"活动第一次创建的时候调用>> onCreate");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button startNormalActivity = (Button) findViewById(R.id.start_normal_activity);
        Button startDialogActivity = (Button) findViewById(R.id.start_dialog_activity);

        //设置按钮的签听事件
        startNormalActivity.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent = new Intent(MainActivity.this,NormalActivity.class);
                startActivity(intent);
            }
        });

        //设置按钮的签听事件
        startDialogActivity.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent = new Intent(MainActivity.this,DialoActivity.class);
                startActivity(intent);
            }
        });

        }
    protected void onStart(){
        super.onStart();
        Log.w(TAG,"活动由不可见变为可见的时候调用>> onStart");
    }

    protected  void onResume(){
        super.onResume();
        Log.w(TAG,"活动准备好和用户进行交互的时候调用>> Onresume");
    }

    protected  void onPause(){
        super.onPause();
        Log.w(TAG,"系统准备去启动或者恢复另一个活动的时候调用>> onpause");
    }

    protected  void onStop(){
        super.onStop();
        Log.w(TAG,"活动完全不可见的时候调用>> onstop");
    }

    protected void onDestroy(){
        super.onDestroy();
        Log.w(TAG,"活动被销毁之前调用>> onDestroy");
    }

    protected void onRestart(){
        super.onRestart();
        Log.w(TAG,"活动由停止状态变为运行状态之前调用>> onRestart");
    }
}
